var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/orders/route.js")
R.c("server/chunks/[externals]__18og1f9d5crv-._.js")
R.c("server/chunks/[root-of-the-server]__1r7kbfkiw2xmu._.js")
R.c("server/chunks/[root-of-the-server]__1k8pig_y_keq3._.js")
R.c("server/chunks/_next-internal_server_app_api_orders_route_actions_18oip2yr4_bzt.js")
R.m(36883)
module.exports=R.m(36883).exports
