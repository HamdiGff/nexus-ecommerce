#1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:"/_next/static/chunks/3ap-rhvazwsfh.js"
4:"/_next/static/chunks/030gkeg3_-kn3.js"
5:"/_next/static/chunks/125h7h7z6vvkz.js"
6:I[20570,["$3","$4","$5"],"default"]
7:I[3265,["$3","$4","$5"],"default"]
8:I[39756,["$3","$4","$5"],"default"]
9:I[37457,["$3","$4","$5"],"default"]
a:I[35171,["$3","$4","$5"],"default"]
b:I[15298,["$3","$4","$5"],"default"]
c:I[58234,["$3","$4","$5"],"default"]
11:I[97367,["$3","$4","$5"],"OutletBoundary"]
14:"ViewportBoundary"
15:I[97367,["$3","$4","$5"],"$14"]
17:"MetadataBoundary"
18:I[97367,["$3","$4","$5"],"$17"]
1b:I[68027,["$3","$4","$5"],"default",1]
:HL["/_next/static/chunks/1frrlw-0ioxd4.css","style"]
:HL["/_next/static/chunks/393w5oikhf558.css","style"]
d:X
f:X
13:X
10:[["children",{"s":"__PAGE__","h":514,"d":{"r":["$","$1","c",{"children":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":"$0:t:t:d:r:props:children:1:props:children:props:children:2:props:children:props:notFound:0:1:props:style","children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":"$0:t:t:d:r:props:children:1:props:children:props:children:2:props:children:props:notFound:0:1:props:children:props:children:1:props:style","children":404}],["$","div",null,{"style":"$0:t:t:d:r:props:children:1:props:children:props:children:2:props:children:props:notFound:0:1:props:children:props:children:2:props:style","children":["$","h2",null,{"style":"$0:t:t:d:r:props:children:1:props:children:props:children:2:props:children:props:notFound:0:1:props:children:props:children:2:props:children:props:style","children":"This page could not be found."}]}]]}]}]],null,["$","$L11",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@12"}]}]]}],"p":true,"v":"$13"}}]]
e:[["children",{"s":"/_not-found","h":514,"d":{"r":["$","$1","c",{"children":[null,["$","$L8",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L9",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$f"},"c":"$Q10"}]]
1a:X
1c:X
1d:X
0:{"P":null,"c":["","_not-found"],"q":"","i":false,"t":{"t":{"s":"","h":530,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1frrlw-0ioxd4.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/393w5oikhf558.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/3ap-rhvazwsfh.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/030gkeg3_-kn3.js","async":true,"nonce":"$undefined"}],["$","script","script-2",{"src":"/_next/static/chunks/125h7h7z6vvkz.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"vtcsSW_variable _78ed6G_variable h-full antialiased scroll-smooth dark","children":["$","body",null,{"className":"min-h-full flex flex-col bg-[#090a0f] text-neutral-100 font-sans selection:bg-blue-600 selection:text-white","children":[["$","$2",null,{"fallback":null,"children":["$","$L6",null,{}]}],["$","$2",null,{"fallback":null,"children":["$","$L7",null,{}]}],["$","main",null,{"className":"flex-1","children":["$","$L8",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L9",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","$2",null,{"fallback":null,"children":["$","$La",null,{}]}],["$","$2",null,{"fallback":null,"children":["$","$Lb",null,{}]}],["$","$2",null,{"fallback":null,"children":["$","$Lc",null,{}]}]]}]}]]}],"p":true,"v":"$d"},"c":"$Qe"},"h":{"r":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L15",null,{"children":"$L16"}],["$","$L18",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$2",null,{"name":"Next.Metadata","children":"$L19"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":true,"v":"$1a"}},"m":"$undefined","G":["$1b",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1frrlw-0ioxd4.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/393w5oikhf558.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$1c","s":"$1d","a":"$@1e","l":"$undefined","p":"$undefined","d":"$undefined","b":"7TCHYloJZudUkk0KupMRN","u":"$@1f"}
f:C
1d:300
16:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
20:I[27201,["$3","$4","$5"],"IconMark"]
12:null
19:[["$","title","0",{"children":"NEXUS Digital | WordPress Licenses, Software Keys & Turnkey Websites"}],["$","meta","1",{"name":"description","content":"The premier digital goods marketplace. Buy Rank Math Pro, WP Rocket, IDM lifetime keys, Steam cards, and Google AdSense approved websites with instant delivery."}],["$","meta","2",{"name":"author","content":"NEXUS Digital Commerce"}],["$","meta","3",{"name":"keywords","content":"rank math pro license,wp rocket cheap,astra pro theme,idm lifetime serial key,buy steam gift card crypto,adsense approved website for sale,instant digital delivery"}],["$","meta","4",{"name":"creator","content":"NEXUS Digital"}],["$","meta","5",{"name":"publisher","content":"NEXUS Digital"}],["$","meta","6",{"name":"robots","content":"index, follow"}],["$","meta","7",{"name":"googlebot","content":"index, follow, max-video-preview:-1, max-image-preview:large, max-snippet:-1"}],["$","meta","8",{"property":"og:title","content":"NEXUS Digital | WordPress Licenses, Software Keys & Turnkey Websites"}],["$","meta","9",{"property":"og:description","content":"Official WordPress agency licenses, instant software activation codes, and turnkey AdSense monetized websites."}],["$","meta","10",{"property":"og:site_name","content":"NEXUS Digital Marketplace"}],["$","meta","11",{"property":"og:locale","content":"en_US"}],["$","meta","12",{"property":"og:type","content":"website"}],["$","meta","13",{"name":"twitter:card","content":"summary"}],["$","meta","14",{"name":"twitter:title","content":"NEXUS Digital | WordPress Licenses, Software Keys & Turnkey Websites"}],["$","meta","15",{"name":"twitter:description","content":"Official WordPress agency licenses, instant software activation codes, and turnkey AdSense monetized websites."}],["$","link","16",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L20","17",{}]]
1d:C
1a:C
1c:C
13:C
d:C
1f:false
1e:null
