globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/7TCHYloJZudUkk0KupMRN/_buildManifest.js",
    "static/7TCHYloJZudUkk0KupMRN/_ssgManifest.js",
    "static/7TCHYloJZudUkk0KupMRN/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1x6obpmlu1_c2.js",
    "static/chunks/06bs-nf19b2js.js",
    "static/chunks/1vo0wohvofgd7.js",
    "static/chunks/3l_qmp-61z4yc.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/06bs-nf19b2js.js",
        "static/chunks/1vo0wohvofgd7.js",
        "static/chunks/3l_qmp-61z4yc.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/06bs-nf19b2js.js",
        "static/chunks/1vo0wohvofgd7.js",
        "static/chunks/3l_qmp-61z4yc.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/06bs-nf19b2js.js",
        "static/chunks/1vo0wohvofgd7.js",
        "static/chunks/3l_qmp-61z4yc.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/06bs-nf19b2js.js",
        "static/chunks/1vo0wohvofgd7.js",
        "static/chunks/3l_qmp-61z4yc.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/category/[slug]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/06bs-nf19b2js.js",
        "static/chunks/1vo0wohvofgd7.js",
        "static/chunks/3l_qmp-61z4yc.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/checkout/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/06bs-nf19b2js.js",
        "static/chunks/1vo0wohvofgd7.js",
        "static/chunks/3l_qmp-61z4yc.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/orders/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/06bs-nf19b2js.js",
        "static/chunks/1vo0wohvofgd7.js",
        "static/chunks/3l_qmp-61z4yc.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/orders/[id]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/06bs-nf19b2js.js",
        "static/chunks/1vo0wohvofgd7.js",
        "static/chunks/3l_qmp-61z4yc.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/products/[slug]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/06bs-nf19b2js.js",
        "static/chunks/1vo0wohvofgd7.js",
        "static/chunks/3l_qmp-61z4yc.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/support/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/06bs-nf19b2js.js",
        "static/chunks/1vo0wohvofgd7.js",
        "static/chunks/3l_qmp-61z4yc.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
