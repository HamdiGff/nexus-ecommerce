module.exports = {
  apps: [
    {
      name: "nexus-store",
      script: "server.js",
      env: {
        NODE_ENV: "production",
        PORT: process.env.PORT || 3000
      }
    }
  ]
};
