:HL["/_next/static/chunks/1frrlw-0ioxd4.css","style"]
:HL["/_next/static/chunks/393w5oikhf558.css","style"]
:HL["/_next/static/media/70bc3e132a0a741e-s.p.3t6q91iet4nsy.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/fba5a26ea33df6a3-s.p.18rizl4rsrl42.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
2:[["children",{"s":"__PAGE__","h":49314}]]
1:[["children",{"s":"orders","h":49250,"c":"$Q2"}]]
0:{"b":"7TCHYloJZudUkk0KupMRN","t":{"t":{"s":"","h":49234,"c":"$Q1"}}}
