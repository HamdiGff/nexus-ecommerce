:HL["/_next/static/chunks/1frrlw-0ioxd4.css","style"]
:HL["/_next/static/chunks/393w5oikhf558.css","style"]
:HL["/_next/static/media/70bc3e132a0a741e-s.p.3t6q91iet4nsy.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/fba5a26ea33df6a3-s.p.18rizl4rsrl42.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
3:[["children",{"s":"__PAGE__","h":57506}]]
2:[["children",{"s":{"n":"slug","t":"d","k":null,"s":[]},"h":57442,"c":"$Q3"}]]
1:[["children",{"s":"products","h":57442,"c":"$Q2"}]]
0:{"b":"7TCHYloJZudUkk0KupMRN","t":{"t":{"s":"","h":57426,"c":"$Q1"}}}
