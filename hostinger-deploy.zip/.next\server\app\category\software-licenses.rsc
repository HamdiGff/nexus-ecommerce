#1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:"/_next/static/chunks/3ap-rhvazwsfh.js"
4:"/_next/static/chunks/030gkeg3_-kn3.js"
5:"/_next/static/chunks/125h7h7z6vvkz.js"
6:I[20570,["$3","$4","$5"],"default"]
7:I[3265,["$3","$4","$5"],"default"]
8:I[39756,["$3","$4","$5"],"default"]
9:I[37457,["$3","$4","$5"],"default"]
a:I[35171,["$3","$4","$5"],"default"]
b:I[15298,["$3","$4","$5"],"default"]
c:I[58234,["$3","$4","$5"],"default"]
13:I[97367,["$3","$4","$5"],"OutletBoundary"]
16:"ViewportBoundary"
17:I[97367,["$3","$4","$5"],"$16"]
19:"MetadataBoundary"
1a:I[97367,["$3","$4","$5"],"$19"]
1d:I[68027,["$3","$4","$5"],"default",1]
:HL["/_next/static/chunks/1frrlw-0ioxd4.css","style"]
:HL["/_next/static/chunks/393w5oikhf558.css","style"]
:HL["/_next/static/media/70bc3e132a0a741e-s.p.3t6q91iet4nsy.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/fba5a26ea33df6a3-s.p.18rizl4rsrl42.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
d:X
f:X
15:X
11:[["children",{"s":"__PAGE__","h":514,"d":{"r":["$","$1","c",{"children":["$L12",[["$","script","script-0",{"src":"/_next/static/chunks/0xbqzt5pfvc1s.js","async":true,"nonce":"$undefined"}]],["$","$L13",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@14"}]}]]}],"p":true,"v":"$15"}}]]
10:[["children",{"s":{"n":"slug","t":"d","k":"software-licenses","s":[]},"h":514,"d":{"r":["$","$1","c",{"children":[null,["$","$L8",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L9",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$f"},"c":"$Q11"}]]
e:[["children",{"s":"category","h":514,"d":{"r":["$","$1","c",{"children":[null,["$","$L8",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L9",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$f"},"c":"$Q10"}]]
1c:X
1e:X
1f:X
0:{"P":null,"c":["","category","software-licenses"],"q":"","i":false,"t":{"t":{"s":"","h":530,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1frrlw-0ioxd4.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/393w5oikhf558.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/3ap-rhvazwsfh.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/030gkeg3_-kn3.js","async":true,"nonce":"$undefined"}],["$","script","script-2",{"src":"/_next/static/chunks/125h7h7z6vvkz.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"vtcsSW_variable _78ed6G_variable h-full antialiased scroll-smooth dark","children":["$","body",null,{"className":"min-h-full flex flex-col bg-[#090a0f] text-neutral-100 font-sans selection:bg-blue-600 selection:text-white","children":[["$","$2",null,{"fallback":null,"children":["$","$L6",null,{}]}],["$","$2",null,{"fallback":null,"children":["$","$L7",null,{}]}],["$","main",null,{"className":"flex-1","children":["$","$L8",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L9",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","$2",null,{"fallback":null,"children":["$","$La",null,{}]}],["$","$2",null,{"fallback":null,"children":["$","$Lb",null,{}]}],["$","$2",null,{"fallback":null,"children":["$","$Lc",null,{}]}]]}]}]]}],"p":true,"v":"$d"},"c":"$Qe"},"h":{"r":["$","$1","h",{"children":[null,["$","$L17",null,{"children":"$L18"}],["$","$L1a",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$2",null,{"name":"Next.Metadata","children":"$L1b"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":true,"v":"$1c"}},"m":"$undefined","G":["$1d",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1frrlw-0ioxd4.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/393w5oikhf558.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$1e","s":"$1f","a":"$@20","l":"$undefined","p":"$undefined","d":"$undefined","b":"7TCHYloJZudUkk0KupMRN","u":"$@21"}
f:C
1f:300
18:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
15:T4,slug1c:T4,slug22:"/_next/static/chunks/0xbqzt5pfvc1s.js"
23:I[81724,["$3","$4","$5","$22"],"default"]
24:I[27201,["$3","$4","$5"],"IconMark"]
12:["$","$2",null,{"fallback":["$","div",null,{"className":"min-h-screen bg-[#090a0f] text-neutral-400 flex items-center justify-center text-xs font-mono","children":"Loading category..."}],"children":["$","$L23",null,{"slug":"software-licenses"}]}]
14:null
1b:[["$","title","0",{"children":"Software License Keys | NEXUS Digital | NEXUS Digital"}],["$","meta","1",{"name":"description","content":"100% genuine retail and OEM serial keys for Windows, Microsoft Office, and utility software."}],["$","meta","2",{"name":"author","content":"NEXUS Digital Commerce"}],["$","meta","3",{"name":"keywords","content":"rank math pro license,wp rocket cheap,astra pro theme,idm lifetime serial key,buy steam gift card crypto,adsense approved website for sale,instant digital delivery"}],["$","meta","4",{"name":"creator","content":"NEXUS Digital"}],["$","meta","5",{"name":"publisher","content":"NEXUS Digital"}],["$","meta","6",{"name":"robots","content":"index, follow"}],["$","meta","7",{"name":"googlebot","content":"index, follow, max-video-preview:-1, max-image-preview:large, max-snippet:-1"}],["$","meta","8",{"property":"og:title","content":"NEXUS Digital | WordPress Licenses, Software Keys & Turnkey Websites"}],["$","meta","9",{"property":"og:description","content":"Official WordPress agency licenses, instant software activation codes, and turnkey AdSense monetized websites."}],["$","meta","10",{"property":"og:site_name","content":"NEXUS Digital Marketplace"}],["$","meta","11",{"property":"og:locale","content":"en_US"}],["$","meta","12",{"property":"og:type","content":"website"}],["$","meta","13",{"name":"twitter:card","content":"summary"}],["$","meta","14",{"name":"twitter:title","content":"NEXUS Digital | WordPress Licenses, Software Keys & Turnkey Websites"}],["$","meta","15",{"name":"twitter:description","content":"Official WordPress agency licenses, instant software activation codes, and turnkey AdSense monetized websites."}],["$","link","16",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L24","17",{}]]
1f:C
1c:C
1e:C
15:C
d:C
21:false
20:5910
